"""Find and download the OSM extract(s) for an area: the smallest single extract that
contains it, or a smaller set of extracts merged into one file.

Public entry points: :func:`find_extracts` lists the candidates, :func:`get_data_by_area`
downloads the best one. Candidates come from three providers:

- Geofabrik, from the vendored ``geofabrik_index.geojson.gz``, or with ``update=True`` from
  its ``index-v1.json``, fetched and cached next to the downloads;
- BBBike city extracts, from the vendored ``bbbike_index.geojson.gz``, or with
  ``update=True`` from BBBike's list of cities, fetched and cached next to the downloads
  with the boundary of each city the vendored copy does not have;
- Movisda administrative areas and 1°/10° grid tiles, from the index files published at
  https://osm.download.movisda.io (fetched and cached next to the downloads; when the grid
  index cannot be fetched and nothing is cached, the copy vendored as
  ``movisda_grid_index.geojson.gz`` is used).

``get_data_by_area`` returns one extract, or with ``strategy="smallest_total"`` a smaller set of
extracts merged into one file. Candidates are ranked by download size: Movisda's index lists sizes; for the others a HEAD request asks the
server, and the answer is cached for a week. Refresh the vendored snapshots with
``scripts/update_extract_indexes.py``.
"""

import gzip
import hashlib
import io
import json
import logging
import math
import numbers
import os
import re
import time
import warnings
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from urllib.error import HTTPError

import geopandas as gpd
import numpy as np
import pandas as pd
import shapely
from shapely.geometry import box, shape
from shapely.geometry.base import BaseGeometry

from pyrosm._log import log_event
from pyrosm.data.geofabrik_index import (
    _EQUAL_AREA_CRS,
    _bbox_filename,
    _bbox_to_polygon,
    _default_target_dir,
    extract_file_name,
)
from pyrosm.data.geofabrik_index import _INDEX_URL as _GEOFABRIK_INDEX_URL
from pyrosm.data.geofabrik_index import _features_to_gdf
from pyrosm.data.geofabrik_index import _load_index as _load_geofabrik_index
from pyrosm.exceptions import (
    DownloadError,
    ExtractDownloadError,
    ExtractNotFoundError,
    RequestRefusedError,
)
from pyrosm.utils import (
    _file_identity,
    _stacklevel_outside_pyrosm,
    check_bounds,
    validate_workers,
)
from pyrosm.utils.progress import stepping, validate_progress
from pyrosm.utils.download import (
    _CHUNK,
    _FETCH_ERRORS,
    _LocalWriteError,
    _TIMEOUT,
    _Net,
    _call_local,
    _content_length,
    _retry,
    copy_atomic,
    download_dir,
    sources_record,
    write_atomic,
)

_BBBIKE_INDEX_PATH = Path(__file__).parent / "bbbike_index.geojson.gz"
_BBBIKE_URL = "https://download.bbbike.org/osm/bbbike"
_MOVISDA_GRID_PATH = Path(__file__).parent / "movisda_grid_index.geojson.gz"
_MOVISDA_URL = "https://osm.download.movisda.io"
_MOVISDA_INDEXES = {
    "admin": "admin/Admin-latest.geojson",
    "grid": "grid/grid-latest.geojson",
}
_INDEX_MAX_AGE = 24 * 3600
_SIZE_MAX_AGE = 7 * 24 * 3600
_COLUMNS = ["provider", "id", "name", "url", "bytes", "contains", "geometry"]
_STRATEGIES = ("single", "smallest_total")
# Uncovered area (m²) below which a set of extracts counts as covering the area; provider
# outlines are simplified, so their edges leave slivers.
_SLIVER_M2 = 1.0
# The default share of an area that may lie outside the extract or extracts that count as
# containing it (``tolerance``).
_TOLERANCE = 0.001
# A download of this many bytes or more is checked for a smaller extract that leaves out
# little of the area: one of at most a tenth of its size that leaves out less than 1 %.
_LARGE_DOWNLOAD = 1e9
# Radius (m) that gives the points and lines of ``must_cover`` an area for the greedy steps.
_POINT_RADIUS_M = 1.0

logger = logging.getLogger(__name__)

# The steps of finding the extracts, and their shares from a first use (the indexes not
# cached yet).
_READING_INDEXES = "reading the extract indexes"
_READING_SIZES = "reading the extract sizes"
_FIND_SHARES = {_READING_INDEXES: 7.7, _READING_SIZES: 0.4}

_bbbike_cache = None
_vendored_sizes_cache = None
_movisda_cache = {}


def _candidate_frame(provider, ids, names, urls, sizes, geometry):
    """One provider's candidates; invalid extent polygons (a few providers publish
    self-intersecting ones) are repaired so containment tests stay reliable."""
    return gpd.GeoDataFrame(
        {
            "provider": provider,
            "id": list(ids),
            "name": list(names),
            "url": list(urls),
            "bytes": list(sizes),
        },
        geometry=gpd.GeoSeries(list(geometry)).make_valid().values,
        crs="EPSG:4326",
    )


def _read_geofabrik_index(data):
    """Geofabrik's index (the bytes of ``index-v1.json``) as a frame with a ``pbf`` column.

    Raises ``ValueError`` when it cannot be read.
    """
    try:
        gdf = _features_to_gdf(json.loads(data)["features"])
        if gdf.empty or gdf["pbf"].isna().all():
            raise ValueError("it lists no extracts")
        return gdf
    except Exception as e:
        raise ValueError("could not read Geofabrik's index (%s)" % e) from e


def _geofabrik_extracts(directory, update=False, net=None):
    """Geofabrik's extracts as candidate rows, from pyrosm's copy of its index or, with
    ``update``, from the index fetched anew and kept in ``<directory>/geofabrik``. When it
    cannot be fetched, the kept copy is used, or else pyrosm's, with a warning."""
    gdf = _load_geofabrik_index()
    if update:
        try:
            path = _cached_index(
                _GEOFABRIK_INDEX_URL,
                Path(directory) / "geofabrik" / "index-v1.json",
                update,
                check=_read_geofabrik_index,
                net=net,
            )
            gdf = _read_geofabrik_index(path.read_bytes())
        except (*_FETCH_ERRORS, ValueError) as e:
            warnings.warn(
                "Geofabrik's index is unavailable (%s); using pyrosm's copy of it from "
                "%s." % (e, gdf.attrs["snapshot_date"]),
                stacklevel=_stacklevel_outside_pyrosm(),
            )
    names = gdf["name"].fillna(gdf["id"])
    return _candidate_frame(
        "Geofabrik", gdf["id"], names, gdf["pbf"], [None] * len(gdf), gdf.geometry
    )


def _parse_poly(text):
    """Parse an Osmosis ``.poly`` file into GeoJSON MultiPolygon coordinates.

    Sections whose name starts with ``!`` are holes of the preceding outer ring.
    """
    polygons = []
    lines = [line.strip() for line in text.splitlines()][1:]
    i = 0
    while i < len(lines) and lines[i] != "END":
        section = lines[i]
        ring = []
        i += 1
        while lines[i] != "END":
            lon, lat = (float(v) for v in lines[i].split())
            ring.append([lon, lat])
            i += 1
        i += 1
        if ring[0] != ring[-1]:
            ring.append(ring[0])
        if section.startswith("!"):
            polygons[-1].append(ring)
        else:
            polygons.append([ring])
    return polygons


def _bbbike_boundary(data):
    """The boundary of a BBBike city (the bytes of its ``.poly`` file) as a MultiPolygon.

    Raises ``ValueError`` when it cannot be read.
    """
    try:
        boundary = shape(
            {"type": "MultiPolygon", "coordinates": _parse_poly(data.decode())}
        )
        if boundary.is_empty:
            raise ValueError("it has no polygon")
        return boundary
    except Exception as e:
        raise ValueError("could not read the boundary (%s)" % e) from e


def _bbbike_cities(data):
    """The cities BBBike's download page (its bytes) lists.

    Raises ``ValueError`` when the page lists fewer than 200 cities or not Berlin, as a page
    other than the listing would.
    """
    cities = sorted(set(re.findall(r'href="([A-Za-z][^"/]*)/"', data.decode())))
    if len(cities) < 200 or "Berlin" not in cities:
        raise ValueError("BBBike's page lists only %d cities" % len(cities))
    return cities


def _bbbike_extracts(directory, update=False, net=None):
    """BBBike's city extracts as candidate rows, from pyrosm's copy of its list of cities or,
    with ``update``, from the list fetched anew and kept in ``<directory>/bbbike``: a city
    BBBike no longer lists is left out, and the boundary of a city pyrosm's copy does not
    have is fetched and kept. When the list cannot be fetched, the kept copy is used, or
    else pyrosm's, with a warning."""
    global _bbbike_cache
    if _bbbike_cache is None:
        with gzip.open(_BBBIKE_INDEX_PATH, "rt", encoding="utf-8") as f:
            collection = json.load(f)
        gdf = gpd.GeoDataFrame.from_features(collection["features"])
        _bbbike_cache = _candidate_frame(
            "BBBike",
            gdf["id"],
            gdf["name"],
            gdf["pbf"],
            [None] * len(gdf),
            gdf.geometry,
        )
        _bbbike_cache.attrs["snapshot_date"] = collection["bbbike_snapshot_date"]
    if not update:
        return _bbbike_cache
    folder = Path(directory) / "bbbike"
    try:
        path = _cached_index(
            _BBBIKE_URL + "/", folder / "cities.html", update, _bbbike_cities, net
        )
        cities = _bbbike_cities(path.read_bytes())
    except (*_FETCH_ERRORS, ValueError) as e:
        warnings.warn(
            "BBBike's list of cities is unavailable (%s); using pyrosm's copy of it from "
            "%s." % (e, _bbbike_cache.attrs["snapshot_date"]),
            stacklevel=_stacklevel_outside_pyrosm(),
        )
        return _bbbike_cache
    known = _bbbike_cache[_bbbike_cache["id"].isin(cities)]
    new, boundaries = [], []
    for city in sorted(set(cities) - set(known["id"])):
        url = "%s/%s/%s.poly" % (_BBBIKE_URL, city, city)
        try:
            poly = _cached_index(
                url, folder / (city + ".poly"), False, _bbbike_boundary, net
            )
            boundaries.append(_bbbike_boundary(poly.read_bytes()))
            new.append(city)
        except (*_FETCH_ERRORS, ValueError) as e:
            warnings.warn(
                "Could not read %s (%s); leaving %s out." % (url, e, city),
                stacklevel=_stacklevel_outside_pyrosm(),
            )
    if not new:
        return known
    urls = ["%s/%s/%s.osm.pbf" % (_BBBIKE_URL, c, c) for c in new]
    found = _candidate_frame("BBBike", new, new, urls, [None] * len(new), boundaries)
    return gpd.GeoDataFrame(
        pd.concat([known, found], ignore_index=True), crs="EPSG:4326"
    )


def _tile_id(bounds):
    """Name a grid tile by its south-west corner, e.g. ``N60E024`` or ``S40W080-10``.

    Movisda's own tile names have the east/west letter swapped, so the id is built from the
    tile's geometry; the download URL keeps Movisda's name.
    """
    minx, miny, maxx, _ = (round(v) for v in bounds)
    size = maxx - minx
    name = "%s%02d%s%03d" % (
        "N" if miny >= 0 else "S",
        abs(miny),
        "E" if minx >= 0 else "W",
        abs(minx),
    )
    return name if size == 1 else "%s-%d" % (name, size)


def _check_movisda_index(data, kind):
    """Raise ``ValueError`` unless ``data`` is a Movisda index pyrosm can read.

    Every feature needs a non-empty (Multi)Polygon geometry within lon/lat bounds, a non-empty
    ``prefix``, an integer ``bytes`` between 0 and 2**63 and, for administrative areas, a
    ``name``.
    """

    def readable(feature):
        props = feature["properties"]
        geometry = shape(feature["geometry"])
        minx, miny, maxx, maxy = geometry.bounds
        return (
            feature["geometry"]["type"] in ("Polygon", "MultiPolygon")
            and not geometry.is_empty
            and -180 <= minx <= maxx <= 180
            and -90 <= miny <= maxy <= 90
            and isinstance(props["prefix"], str)
            and props["prefix"] != ""
            and type(props["bytes"]) is int
            and 0 <= props["bytes"] < 2**63
            and (kind != "admin" or isinstance(props["name"], str))
        )

    try:
        features = json.loads(data)["features"]
        valid = bool(features) and all(readable(f) for f in features)
    except Exception:
        valid = False
    if not valid:
        raise ValueError("the response is not a Movisda %s index" % kind)


def _cached_index(url, path, update=False, check=None, net=None, progress=None):
    """Return ``path`` holding the file at ``url``, fetching it when needed.

    ``<path>.etag`` records the ETag, size and SHA-256 of the copy, and its time stamp the last
    check. A copy checked less than a day ago is used as is unless ``update`` is set. Otherwise it
    is revalidated with its ETag (sent only when the copy's hash matches), so an unchanged file is
    not downloaded again. A new file replaces
    the copy only after ``check(data)`` accepts it; when the server cannot be reached or sends
    something ``check`` rejects, the copy is kept with a warning. ``progress(received,
    total)``, when given, follows the download; ``total`` is the size the server gives, or
    else the size of the copy, or None.
    """
    path = Path(path)
    meta_path = path.with_name(path.name + ".etag")
    have_copy = path.exists()
    try:
        meta = json.loads(meta_path.read_text())
        bound = meta["bytes"] == path.stat().st_size
        checked = meta_path.stat().st_mtime if bound else 0
    except (OSError, ValueError, TypeError, KeyError):
        meta, checked = {}, 0
    if have_copy and not update and 0 <= time.time() - checked < _INDEX_MAX_AGE:
        return path
    etag = ""
    if checked and meta.get("sha256") == hashlib.sha256(path.read_bytes()).hexdigest():
        etag = meta.get("etag") or ""
    headers = {"If-None-Match": etag} if etag else None
    net = net or _Net()

    report = progress or (lambda received, total: None)

    def fetch():
        with net.open(url, headers=headers) as response:
            total = _content_length(response.headers.get("Content-Length"))
            expected = total if total is not None else meta.get("bytes")
            chunks, received = [], 0
            _call_local(report, received, expected)
            while chunk := response.read(_CHUNK):
                chunks.append(chunk)
                received += len(chunk)
                _call_local(report, received, expected)
            if total is not None and received != total:
                raise OSError(
                    "The download of '%s' stopped after %d of %d bytes."
                    % (url, received, total)
                )
            return b"".join(chunks), response.headers.get("ETag") or ""

    try:
        data, new_etag = _retry(fetch)
        if check is not None:
            check(data)
        write_atomic(path, lambda out_file: out_file.write(data))
        digest = hashlib.sha256(data).hexdigest()
        meta = json.dumps({"etag": new_etag, "bytes": len(data), "sha256": digest})
        meta = meta.encode()
        write_atomic(meta_path, lambda out_file: out_file.write(meta))
    except HTTPError as e:
        if e.code == 304 and have_copy:
            if hashlib.sha256(path.read_bytes()).hexdigest() == meta.get("sha256"):
                record = json.dumps(meta).encode()
                write_atomic(meta_path, lambda out_file: out_file.write(record))
        elif have_copy:
            warnings.warn(
                "Could not refresh %s (%s); using the cached copy." % (url, e),
                stacklevel=_stacklevel_outside_pyrosm(),
            )
        else:
            raise
    except (*_FETCH_ERRORS, ValueError) as e:
        if not have_copy:
            raise
        warnings.warn(
            "Could not refresh %s (%s); using the cached copy." % (url, e),
            stacklevel=_stacklevel_outside_pyrosm(),
        )
    return path


def _movisda_frame(source, kind):
    """Read a Movisda index (a path or file object) into candidate rows.

    Raises ``ValueError`` when it cannot be read.
    """
    try:
        gdf = gpd.read_file(source)
        urls = [
            "%s/%s/%slatest.osm.pbf" % (_MOVISDA_URL, kind, p) for p in gdf["prefix"]
        ]
        if kind == "admin":
            ids = gdf["prefix"].str.rstrip("-")
            names = gdf["name"]
            if "name_en" in gdf:
                names = gdf["name_en"].fillna(names)
        else:
            ids = [_tile_id(g.bounds) for g in gdf.geometry]
            names = ["%s tile %s" % (kind, i) for i in ids]
        return _candidate_frame("Movisda", ids, names, urls, gdf["bytes"], gdf.geometry)
    except Exception as e:
        raise ValueError("could not read the Movisda %s index (%s)" % (kind, e)) from e


def _movisda_index_frame(kind, path):
    """The candidate rows of the Movisda index at ``path``, parsed once while the file is
    unchanged. A ``.gz`` file is pyrosm's vendored copy; its date is in ``attrs``."""
    key = (str(path), path.stat().st_mtime_ns)
    cached = _movisda_cache.get(kind)
    if cached is not None and cached[0] == key:
        return cached[1]
    if path.suffix == ".gz":
        data = gzip.decompress(path.read_bytes())
        frame = _movisda_frame(io.BytesIO(data), kind)
        frame.attrs["snapshot_date"] = json.loads(data).get("movisda_snapshot_date")
    else:
        frame = _movisda_frame(path, kind)
    _movisda_cache[kind] = (key, frame)
    return frame


def _movisda_extracts(directory, update=False, net=None, progress=None):
    """Movisda's administrative areas and grid tiles as candidate rows.

    When an index cannot be fetched and no copy is cached, the administrative areas are left
    out and the grid tiles come from pyrosm's vendored copy, each with a warning.
    ``progress(done, total)``, when given, follows the downloads of the indexes.
    """
    frames = []
    count = len(_MOVISDA_INDEXES)
    for i, (kind, rel) in enumerate(_MOVISDA_INDEXES.items()):

        def index_progress(received, total, i=i):
            if total:
                progress(i + min(received / total, 1.0), count)

        try:
            path = _cached_index(
                "%s/%s" % (_MOVISDA_URL, rel),
                Path(directory) / "movisda" / Path(rel).name,
                update,
                check=lambda data, kind=kind: _check_movisda_index(data, kind)
                or _movisda_frame(io.BytesIO(data), kind),
                net=net,
                progress=None if progress is None else index_progress,
            )
            frames.append(_movisda_index_frame(kind, path))
        except (*_FETCH_ERRORS, ValueError) as e:
            if kind == "admin":
                warnings.warn(
                    "Movisda's administrative index is unavailable (%s); skipping its "
                    "administrative areas." % e,
                    stacklevel=_stacklevel_outside_pyrosm(),
                )
                continue
            frame = _movisda_index_frame(kind, _MOVISDA_GRID_PATH)
            warnings.warn(
                "Movisda's grid index is unavailable (%s); using pyrosm's copy of it "
                "from %s." % (e, frame.attrs["snapshot_date"]),
                stacklevel=_stacklevel_outside_pyrosm(),
            )
            frames.append(frame)
    return pd.concat(frames, ignore_index=True)


def _size_record(directory, url):
    """The file caching the size of ``url``: one small JSON ``[bytes, checked]`` per URL."""
    name = hashlib.sha1(url.encode()).hexdigest() + ".json"
    return Path(directory) / "extract_sizes" / name


def _cached_size(record, now):
    """Return the size stored in ``record`` if it is valid and younger than a week."""
    try:
        size, checked = json.loads(record.read_text())
        age = now - float(checked)
        if type(size) is int and 0 <= size < 2**63 and 0 <= age < _SIZE_MAX_AGE:
            return size
    except (OSError, ValueError, TypeError, OverflowError):
        pass
    return None


def _vendored_geofabrik_sizes():
    """``{pbf URL: (bytes, day read)}`` recorded in pyrosm's Geofabrik index snapshot (read
    once)."""
    global _vendored_sizes_cache
    if _vendored_sizes_cache is not None:
        return _vendored_sizes_cache
    gdf = _load_geofabrik_index().reindex(columns=["pbf", "bytes", "bytes_date"])
    _vendored_sizes_cache = {
        url: (int(size), day)
        for url, size, day in zip(gdf["pbf"], gdf["bytes"], gdf["bytes_date"])
        if isinstance(url, str) and pd.notna(size) and 0 <= size < 2**63
    }
    return _vendored_sizes_cache


def _download_sizes(
    urls, directory, update=False, net=None, fallback=None, progress=None
):
    """Return ``{url: bytes}`` for ``urls``, from a week-long cache or a HEAD request.

    When a URL's size cannot be read (the server is down, loops, or sends no valid
    ``Content-Length``), its ``(bytes, day)`` in ``fallback`` is used, with a warning; without
    one the URL is left out of the result, with a warning. Only sizes read from the server are
    cached. ``progress(done, total)``, when given, gets the URLs done.
    """
    sizes = {}
    net = net or _Net()
    fallback = fallback or {}

    def unreadable(url, reason):
        recorded = fallback.get(url)
        if recorded is None:
            warnings.warn(
                "Could not get the size of %s (%s); it is ranked last." % (url, reason),
                stacklevel=_stacklevel_outside_pyrosm(),
            )
            return
        sizes[url] = recorded[0]
        warnings.warn(
            "Could not get the size of %s (%s); using the size recorded in pyrosm's "
            "Geofabrik index on %s." % (url, reason, recorded[1]),
            stacklevel=_stacklevel_outside_pyrosm(),
        )

    urls = list(urls)
    for done, url in enumerate(urls):
        if progress is not None:
            progress(done, len(urls))
        record = _size_record(directory, url)
        cached = None if update else _cached_size(record, time.time())
        if cached is not None:
            sizes[url] = cached
            continue

        def head(url=url):
            with net.open(url, method="HEAD") as response:
                return response.headers.get("Content-Length")

        try:
            length = _retry(head)
        except _FETCH_ERRORS as e:
            unreadable(url, e)
            continue
        size = _content_length(length)
        if size is None:
            unreadable(url, "no valid Content-Length")
            continue
        sizes[url] = size
        payload = json.dumps([sizes[url], time.time()]).encode()
        write_atomic(record, lambda out_file: out_file.write(payload))
    if progress is not None:
        progress(len(urls), len(urls))
    return sizes


def find_extracts(
    area,
    contains_only=False,
    update=False,
    directory=None,
    headers=None,
    timeout=_TIMEOUT,
    opener=None,
    must_cover=None,
    progress=None,
    tolerance=_TOLERANCE,
):
    """List the OSM extracts that overlap ``area``, best download first, without downloading.

    See https://pyrosm.readthedocs.io/en/stable/download_responsibly.html
    for what the data providers ask and how pyrosm keeps to it.

    Compares Geofabrik extracts, BBBike city extracts and Movisda administrative areas and
    1°/10° grid tiles. Extracts that contain the whole area (or ``must_cover`` when given) come
    first, then those that only overlap it; within each group the smallest download comes
    first. Extracts whose size cannot be read come last in their group, smallest extent first.
    With its default ``strategy="single"``, :func:`get_data_by_area` downloads the first
    extract that contains the area (or ``must_cover``).

    An extract contains the area also when the part of the area outside it is less than
    ``tolerance`` (0.1 % by default) of the area, such as a strip of sea that a city's
    boundary reaches past the edge of a regional extract. ``must_cover`` gets no tolerance:
    an extract contains its polygons when less than 1 m² of them lies outside it, and its
    points and lines when they lie inside it.

    When Movisda's indexes cannot be fetched and no copy is cached, its administrative areas are
    left out and its grid tiles come from the copy vendored with pyrosm, each with a warning.

    Parameters
    ----------
    area : shapely geometry | GeoDataFrame | GeoSeries | list | tuple | numpy.ndarray
        The area of interest in lon/lat: a (Multi)Polygon, a GeoDataFrame/GeoSeries (its
        geometries are combined) or ``[minx, miny, maxx, maxy]``.

    contains_only : bool
        When ``True``, list only the extracts that contain the whole area (or ``must_cover``).

    update : bool
        When ``True``, refresh the provider indexes (Geofabrik's index, BBBike's list of
        cities and Movisda's indexes) and the download sizes. When an index cannot be
        fetched, its cached copy, or else the copy vendored with pyrosm, is used with a
        warning.

    directory : str, optional
        Directory for the cached provider indexes and download sizes. ``None`` (default) uses
        the pyrosm temp directory, as :func:`get_data_by_area` does.

    headers : dict, optional
        Extra HTTP headers for the index and size requests, e.g. a ``User-Agent``.

    timeout : float | tuple
        Seconds to wait for a server, for the connect and each read, or a ``(connect, read)``
        pair. Default 60.

    opener : object, optional
        An object with ``open(request, timeout=...)``, e.g. from
        ``urllib.request.build_opener()``, that makes the requests instead of pyrosm.

    must_cover : shapely geometry | GeoDataFrame | GeoSeries, optional
        What an extract must contain, in place of the whole area, e.g. the transit stops that
        routing needs. Any geometry type; points and lines must be contained exactly. Extracts
        that only reach it (not the area) are listed too. To also require the streets around
        each stop, pass the stops buffered in a local metric CRS, e.g.
        ``stops.to_crs(stops.estimate_utm_crs()).buffer(300)``, or a hull of them to require
        the streets between stops as well. A GeoDataFrame or GeoSeries in another CRS is
        reprojected to lon/lat.

    progress : bool | callable | None
        ``None`` (default) follows :func:`pyrosm.enable_logging`, which is ``True`` unless
        set. ``True`` shows a bar "Finding the extracts" on stderr once the search has run
        2 seconds, from 0 to 100 % while the extract indexes are downloaded on first use
        and the sizes are read, ``False`` shows nothing, and a callable is called as
        ``progress(done, 100)`` with the percentage done.

    tolerance : float
        The share of the area (``0 <= tolerance < 1``) that may lie outside an extract that
        counts as containing it, or 1 m² when that is more; 0.001 (0.1 %) by default. With
        ``0``, only slivers smaller than 1 m², which the simplified outlines of extracts
        leave, may lie outside. Not used with ``must_cover``.

    Returns
    -------
    GeoDataFrame
        One row per extract with the columns ``provider`` (``"Geofabrik"``, ``"BBBike"`` or
        ``"Movisda"``), ``id``, ``name``, ``url``, ``bytes`` (the download size, ``<NA>`` when
        it cannot be read), ``contains`` (whether the extract contains the whole area, or
        ``must_cover`` when given, as described above) and ``geometry``
        (the extract's extent, EPSG:4326).

    Raises
    ------
    ValueError
        If the area is empty, or has no width or no height, or ``must_cover`` is empty, or
        ``progress`` is not ``True``, ``False``, ``None`` or a callable, or ``tolerance`` is
        not a number with ``0 <= tolerance < 1``.
    """
    validate_progress(progress)
    tolerance = _validate_tolerance(tolerance)
    area = _area_geometry(area)
    parts = None if must_cover is None else _must_cover_parts(must_cover)
    directory = Path(directory) if directory is not None else download_dir()
    net = _Net(headers, timeout, opener)
    with stepping(
        progress,
        "Finding the extracts",
        _FIND_SHARES,
        delay=2.0,
        leave=False,
        timed=True,
    ) as steps:
        indexes = steps.start_step(_READING_INDEXES)
        frames = [
            _geofabrik_extracts(directory, update, net),
            _bbbike_extracts(directory, update, net),
        ]
        try:
            frames.append(_movisda_extracts(directory, update, net, indexes))
        except _LocalWriteError as e:
            raise e.__cause__
        except (*_FETCH_ERRORS, ValueError) as e:
            warnings.warn(
                "Movisda's extract index is unavailable (%s); skipping it." % e,
                stacklevel=_stacklevel_outside_pyrosm(),
            )
        candidates = gpd.GeoDataFrame(
            pd.concat(frames, ignore_index=True), crs="EPSG:4326"
        )
        if parts is None:
            candidates["contains"] = _contain(candidates.geometry, area, tolerance)
        else:
            polygons, exact = parts
            candidates["contains"] = True
            if polygons is not None:
                candidates["contains"] &= _contain(candidates.geometry, polygons, 0)
            if exact is not None:
                candidates["contains"] &= candidates.covers(exact)
        if contains_only:
            found = candidates[candidates["contains"]].copy()
        else:
            overlaps = candidates.intersects(area) & ~candidates.touches(area)
            for part in parts or ():
                if part is not None:
                    overlaps |= candidates.intersects(part)
            found = candidates[overlaps].copy()
        unknown = found["bytes"].isna()
        sizes = _download_sizes(
            found.loc[unknown, "url"],
            directory,
            update,
            net,
            _vendored_geofabrik_sizes(),
            steps.start_step(_READING_SIZES),
        )
    found["bytes"] = pd.array(
        [
            sizes.get(url) if pd.isna(size) else int(size)
            for size, url in zip(found["bytes"], found["url"])
        ],
        dtype="Int64",
    )
    found["_area"] = found.geometry.to_crs(_EQUAL_AREA_CRS).area
    ranked = found.sort_values(
        ["contains", "bytes", "_area", "provider", "id"],
        ascending=[False, True, True, True, True],
        na_position="last",
        kind="stable",
    )
    return ranked[_COLUMNS].reset_index(drop=True)


def _allowed_gap_m2(polygon_m2, tolerance):
    """The area (m²) of a polygon target of ``polygon_m2`` m² that may lie outside the
    extracts that count as containing it: a sliver, or the share ``tolerance`` of the
    target when that is more."""
    return max(_SLIVER_M2, tolerance * polygon_m2)


def _validate_tolerance(tolerance):
    """``tolerance`` as a float, or ``ValueError`` when it is not a number from 0 up to
    (not including) 1."""
    if (
        isinstance(tolerance, bool)
        or not isinstance(tolerance, numbers.Real)
        or not 0 <= tolerance < 1
    ):
        raise ValueError(
            "tolerance must be a share of the area from 0 up to 1, such as 0.001; got %r."
            % (tolerance,)
        )
    return float(tolerance)


def _projected(geom):
    """``geom`` (lon/lat) in the equal-area CRS, which measures areas in m²; ``None`` for
    ``None``."""
    if geom is None:
        return None
    return gpd.GeoSeries([geom], crs="EPSG:4326").to_crs(_EQUAL_AREA_CRS).iloc[0]


def _contain(outlines, area, tolerance):
    """Whether each of the extract ``outlines`` (a lon/lat GeoSeries) contains ``area``:
    covers it, or, for a polygonal ``area``, leaves less than :func:`_allowed_gap_m2` of
    it outside with ``tolerance``."""
    contains = outlines.covers(area)
    near = ~contains & outlines.intersects(area)
    if area.area > 0 and near.any():
        gaps, total = _uncovered_m2(outlines[near], area)
        contains[near] = gaps < _allowed_gap_m2(total, tolerance)
    return contains


def _uncovered_m2(outlines, polygon):
    """The area (m²) of ``polygon`` outside each of the extract ``outlines`` (a lon/lat
    GeoSeries), and the area of ``polygon`` (lon/lat), both in the equal-area CRS."""
    projected = _projected(polygon)
    shapes = outlines.to_crs(_EQUAL_AREA_CRS).values
    return shapely.area(shapely.difference(projected, shapes)), projected.area


def _size_text(size):
    """A download size in bytes as text, such as ``65 MB`` or ``4.2 GB``."""
    if pd.isna(size):
        return "size unknown"
    if size >= 1e9:
        return "%.1f GB" % (size / 1e9)
    return ("%.1f MB" if size < 1e7 else "%.0f MB") % (size / 1e6)


def _number_text(value):
    """``value`` as text with two significant digits and no exponent, such as ``150``,
    ``0.085`` or ``0.00004``."""
    return np.format_float_positional(
        value, precision=2, unique=False, fractional=False, trim="-"
    )


def _tolerance_above(share):
    """A round tolerance above ``share`` (greater than 0), such as 0.0005 for 0.00043 and
    0.0006 for 0.0005, also when ``share`` was rounded down a little in its division."""
    share *= 1 + 1e-9
    step = 10 ** math.floor(math.log10(share))
    return float("%g" % ((math.floor(share / step) + 1) * step))


def _warn_large_download(chosen, downloaded, overlapping, polygons, tolerance):
    """Warn before the extracts ``chosen`` not ``downloaded`` yet (URLs) are downloaded
    when their sizes are known and total at least :data:`_LARGE_DOWNLOAD` bytes, and an
    extract that ``overlapping()`` gives (also one of a set ``chosen``), of at most a
    tenth of that size, leaves out more than nothing but less than 1 % of ``polygons``:
    naming the smallest such extract, what it leaves out and, with a ``tolerance`` (for
    the area), a tolerance of at most 1 % with which pyrosm can use it."""
    pending = chosen[~chosen["url"].isin(list(downloaded))]
    sizes = pending["bytes"]
    if sizes.isna().any() or sizes.sum() < _LARGE_DOWNLOAD:
        return
    if polygons is None or polygons.area == 0:
        return
    size = sizes.sum()
    overlapping = overlapping()
    smaller = overlapping[(overlapping["bytes"] <= size / 10).fillna(False)]
    if len(chosen) == 1:
        smaller = smaller[smaller["url"] != chosen["url"].iloc[0]]
    smaller = smaller[smaller.intersects(polygons) & ~smaller.touches(polygons)]
    if smaller.empty:
        return
    gaps, total = _uncovered_m2(smaller.geometry, polygons)
    shares = pd.Series(gaps / total, index=smaller.index)
    near = smaller[(shares > 0) & (shares < 0.01)].sort_values("bytes", kind="stable")
    if near.empty:
        return
    other = near.iloc[0]
    share = shares[other.name]
    names = " + ".join("%s %s" % e for e in zip(pending["provider"], pending["id"]))
    message = (
        "pyrosm is about to download %s (%s). %s %s (%s) leaves out only %s %% of %s."
        % (
            names,
            _size_text(size),
            other.provider,
            other.id,
            _size_text(other.bytes),
            _number_text(100 * share),
            "the area" if tolerance is not None else "must_cover",
        )
    )
    suggested = None if tolerance is None else _tolerance_above(share)
    if suggested is not None and suggested <= 0.01:
        message += " With tolerance=%g, pyrosm can use %s %s instead." % (
            suggested,
            other.provider,
            other.id,
        )
    warnings.warn(message, stacklevel=_stacklevel_outside_pyrosm())


def _not_found_message(what, candidates, polygons, tolerance):
    """The message of :class:`~pyrosm.exceptions.ExtractNotFoundError` for ``what`` (the
    area or ``must_cover``): up to three of ``candidates`` that leave the least of
    ``polygons`` outside them and, with a ``tolerance`` (for the area), a tolerance of at
    most 1 % with which pyrosm could use the first of them."""
    if tolerance is None:
        message = "No Geofabrik, BBBike or Movisda extract contains %s." % what
    else:
        message = (
            "No Geofabrik, BBBike or Movisda extract contains enough of %s "
            "(tolerance=%g)." % (what, tolerance)
        )
    if polygons is None or polygons.area == 0:
        return message
    overlap = candidates.intersects(polygons) & ~candidates.touches(polygons)
    overlapping = candidates[overlap]
    if overlapping.empty:
        return message
    gaps, total = _uncovered_m2(overlapping.geometry, polygons)
    shares = pd.Series(gaps / total, index=overlapping.index).sort_values(kind="stable")
    closest = overlapping.loc[shares.index[:3]]
    message += " These extracts cover the largest part of %s:" % what + "".join(
        "\n- %s %s (%s): %s %%"
        % (e.provider, e.id, _size_text(e.bytes), _number_text(100 * shares[i]))
        for i, e in zip(closest.index, closest.itertuples())
    )
    best = shares.iloc[0]
    if tolerance is None or best == 0:
        return message
    suggested = _tolerance_above(best)
    if suggested <= 0.01:
        first = closest.iloc[0]
        message += (
            "\nWith tolerance=%g, pyrosm can use %s %s, which leaves out %s %% of %s."
            % (suggested, first.provider, first.id, _number_text(100 * best), what)
        )
    return message


def _warn_uncovered(chosen, target):
    """Warn when the extracts ``chosen`` leave more than a sliver of the polygons of
    ``target`` (see :func:`_smallest_cover`) outside them, naming how much and where (see
    :func:`_where_left_out`)."""
    polygons = target[0]
    if polygons is None or polygons.area == 0:
        return
    if shapely.union_all(chosen.geometry.values).covers(polygons):
        return
    polygon = _projected(polygons)
    outlines = shapely.union_all(chosen.geometry.to_crs(_EQUAL_AREA_CRS).values)
    gap = polygon.difference(outlines)
    if gap.area < _SLIVER_M2:
        return
    names = " + ".join("%s %s" % e for e in zip(chosen["provider"], chosen["id"]))
    warnings.warn(
        "%s %s out %s km² (%s %%) of the area.%s"
        % (
            names,
            "leaves" if len(chosen) == 1 else "leave",
            _number_text(gap.area / 1e6),
            _number_text(100 * gap.area / polygon.area),
            _where_left_out(gap, polygon),
        ),
        stacklevel=_stacklevel_outside_pyrosm(),
    )


def _where_left_out(gap, polygon):
    """Where the part ``gap`` of ``polygon`` (both in the equal-area CRS) lies, as a
    sentence: within its bounds (lon/lat) when they span at most half of the polygon's
    width or height, else along the polygon's edge when every piece of it borders both
    the edge and the rest of the polygon along a line (a whole island left out borders
    no rest, a hole in the extracts no edge), else spread across the polygon."""
    gap_x0, gap_y0, gap_x1, gap_y1 = gap.bounds
    x0, y0, x1, y1 = polygon.bounds
    if gap_x1 - gap_x0 <= (x1 - x0) / 2 or gap_y1 - gap_y0 <= (y1 - y0) / 2:
        bounds = (
            gpd.GeoSeries([gap], crs=_EQUAL_AREA_CRS).to_crs("EPSG:4326").total_bounds
        )
        return " This part lies within the bounds [%s]." % ", ".join(
            "%.3f" % b for b in bounds
        )
    pieces = shapely.get_parts(gap)
    outline, edge = gap.boundary, polygon.boundary
    along = _pieces_bordering(pieces, outline.intersection(edge)) & _pieces_bordering(
        pieces, outline.difference(edge)
    )
    if along.all():
        return " This part lies along the edge of the area."
    return " This part is spread across the area."


def _pieces_bordering(pieces, lines):
    """Whether each of the polygons ``pieces`` has one of ``lines`` (parts of their
    boundaries) along its boundary, found by the middle point of each line, so that a
    piece that only touches a line at its end does not count."""
    parts = shapely.get_parts(lines)
    parts = parts[shapely.length(parts) > 0]
    found = np.zeros(len(pieces), dtype=bool)
    if len(parts):
        middles = shapely.line_interpolate_point(parts, 0.5, normalized=True)
        # Within 1 µm, but closer to the middle than to the line's ends.
        near = np.minimum(1e-6, shapely.length(parts) / 4)
        tree = shapely.STRtree(pieces)
        found[tree.query(middles, predicate="dwithin", distance=near)[1]] = True
    return found


def _covers(chosen, shapes, outlines, polygons, exact, allowed):
    """Whether the extracts ``chosen`` cover the polygon part (all but ``allowed`` m²,
    measured on the projected ``shapes``) and the point and line part (exactly, on the
    lon/lat ``outlines``) of a coverage target."""
    if not chosen:
        return False
    if polygons is not None:
        left = polygons.difference(shapely.union_all(shapes.loc[chosen]))
        if left.area >= allowed:
            return False
    return exact is None or shapely.union_all(outlines.loc[chosen]).covers(exact)


def _prune(chosen, sizes, covered):
    """Drop extracts from ``chosen``, largest first, while ``covered(rest)`` holds."""
    for i in sorted(chosen, key=lambda i: -sizes[i]):
        rest = [j for j in chosen if j != i]
        if covered(rest):
            chosen = rest
    return chosen


def _greedy_cover(target, shapes, sizes, chosen, pool, allowed):
    """Extend ``chosen`` with extracts from ``pool`` while they leave ``allowed`` m² or more
    of ``target`` uncovered, each time taking the lowest ``bytes`` per area newly covered;
    stop when no extract adds area. ``None`` when nothing at all was chosen."""
    chosen, pool = list(chosen), list(pool)
    remaining = target.difference(shapely.union_all(shapes.loc[chosen]))
    # At least one extract, even for an area smaller than a sliver.
    while not chosen or remaining.area >= allowed:
        gains = {i: shapes[i].intersection(remaining).area for i in pool}
        useful = [i for i in pool if gains[i] > 0]
        if not useful:
            break
        pick = min(useful, key=lambda i: (sizes[i] / gains[i], sizes[i], i))
        chosen.append(pick)
        pool.remove(pick)
        remaining = remaining.difference(shapes[pick])
    return chosen or None


def _repair(chosen, pool, sizes, outlines, exact):
    """Add the cheapest extracts from ``pool`` until ``chosen`` covers the points and lines
    ``exact`` exactly (lon/lat ``outlines`` and ``exact``, so points on an edge keep their
    ``covers`` meaning); ``None`` when no extract holds what is left."""
    chosen, pool = list(chosen), list(pool)
    while exact is not None and not shapely.union_all(outlines.loc[chosen]).covers(
        exact
    ):
        left = exact.difference(shapely.union_all(outlines.loc[chosen]))
        options = [i for i in pool if i not in chosen and outlines[i].intersects(left)]
        if not options:
            return None
        chosen.append(min(options, key=lambda i: (sizes[i], i)))
    return chosen


def _smallest_cover(target, candidates, tolerance=_TOLERANCE):
    """The extracts that together cover ``target`` with a small total download, in merge
    order, or ``None`` when they cannot cover it.

    ``target`` is ``(polygons, points_and_lines)`` in lon/lat, either part ``None``: polygons
    count as covered when less than :func:`_allowed_gap_m2` of them is left with
    ``tolerance``; points and lines must be covered exactly (for the greedy steps they are buffered by 1 m, which
    only guides the choice).
    Candidates are rows of :func:`find_extracts`, in its ranking order. Geofabrik and BBBike
    extracts and Movisda administrative extracts with a known size may be used, at most one of
    them from Movisda; Movisda grid tiles never are (they drop closed ways at tile edges). The
    set is found greedily (lowest bytes per area newly covered), once without Movisda and once
    starting from each Movisda extract, then pruned; the cheapest result wins. It is a good
    set, not necessarily the smallest possible. Movisda comes last in the merge order, so a
    complete copy of a way that crosses its border wins :func:`pyrosm.merge_pbf`'s ties.
    """
    known = candidates[candidates["bytes"].notna()]
    movisda = known["provider"] == "Movisda"
    admin = movisda & known["url"].str.contains("/admin/", regex=False)
    known = known[~movisda | admin]

    polygons, exact = _projected(target[0]), target[1]
    guide = [polygons] if polygons is not None else []
    if exact is not None:
        guide.append(_projected(exact).buffer(_POINT_RADIUS_M))
    guide = shapely.union_all(guide)
    allowed = _SLIVER_M2
    if polygons is not None:
        allowed = _allowed_gap_m2(polygons.area, tolerance)
    # Projected and clipped to the target once, so the greedy steps work on small shapes;
    # the lon/lat outlines decide exact coverage; sizes stay exact Python integers.
    outlines = known.geometry
    shapes = outlines.to_crs(_EQUAL_AREA_CRS).intersection(guide)
    sizes = {i: int(size) for i, size in known["bytes"].items()}
    others = list(known.index[known["provider"] != "Movisda"])
    best = None
    for seed in [None] + list(known.index[known["provider"] == "Movisda"]):
        start = [] if seed is None else [seed]
        chosen = _greedy_cover(guide, shapes, sizes, start, others, allowed)
        if chosen is not None:
            chosen = _repair(chosen, others, sizes, outlines, exact)
        if chosen is None or not _covers(
            chosen, shapes, outlines, polygons, exact, allowed
        ):
            continue
        chosen = _prune(
            chosen,
            sizes,
            lambda rest: _covers(rest, shapes, outlines, polygons, exact, allowed),
        )
        key = (sum(sizes[i] for i in chosen), len(chosen))
        if best is None or key < best[0]:
            best = (key, chosen)
    if best is None:
        return None
    order = sorted(best[1], key=lambda i: (known.at[i, "provider"] == "Movisda", i))
    return known.loc[order]


def _choose(target, candidates, strategy, tolerance=_TOLERANCE):
    """The extract(s) to download, or ``None``: the first extract that contains ``target``
    (see :func:`_smallest_cover`, with ``tolerance``); with ``strategy="smallest_total"``
    a set of extracts when its total is smaller than that extract, or when that extract's
    size is unknown."""
    single = candidates[candidates["contains"]].iloc[:1]
    if strategy == "single":
        return single if len(single) else None
    cover = _smallest_cover(target, candidates, tolerance)
    if cover is None:
        return single if len(single) else None
    size = single["bytes"].iloc[0] if len(single) else pd.NA
    if pd.notna(size) and int(size) <= sum(int(b) for b in cover["bytes"]):
        return single
    return cover


def _sha256(path):
    """The SHA-256 hex digest of a file."""
    digest = hashlib.sha256()
    with open(path, "rb") as f:
        while chunk := f.read(1 << 20):
            digest.update(chunk)
    return digest.hexdigest()


def _provenance(path):
    """``(sha256, snapshot)`` of a file: its SHA-256 hex digest and the PBF header's
    ``osmosis_replication_timestamp`` as a UTC datetime (``None`` when it has none).

    Both are read within one check of the file's identity (device, inode, size, mtime): when
    it changed while they were read, they are read again, up to three times, then ``OSError``.
    This is best effort against another process changing the file; pyrosm itself replaces its
    downloads and merges atomically.
    """
    from pyrosm.pbf_export import read_header_block

    for _ in range(3):
        before = _file_identity(path)
        stamp = read_header_block(str(path)).osmosis_replication_timestamp
        digest = _sha256(path)
        if _file_identity(path) == before:
            snapshot = datetime.fromtimestamp(stamp, timezone.utc) if stamp else None
            return digest, snapshot
    raise OSError("'%s' kept changing while it was read." % path)


@dataclass
class ExtractSource:
    """One downloaded extract that went into an :class:`AreaExtract`: where it came from, the
    downloaded file, its SHA-256 and its snapshot time (``None`` when the file has none).
    """

    provider: str
    extract: str
    url: str
    bytes: object
    path: str
    sha256: str = None
    snapshot: object = None


@dataclass
class AreaExtract:
    """The file :func:`get_data_by_area` wrote and the extract(s) it came from.

    It can be used as a path, e.g. ``OSM(get_data_by_area(area))``.

    Attributes
    ----------
    path : str
        The cropped file; with ``crop=False`` the full extract, or the merged extracts.
    provider : str
        ``"Geofabrik"``, ``"BBBike"`` or ``"Movisda"``; for merged extracts their providers
        joined with ``"+"`` in merge order.
    extract : str
        The extract's id at the provider, e.g. ``"finland"``, ``"Basel"``, ``"NL-NB"`` or a grid
        tile such as ``"N60E024"`` (south-west corner; ``"-10"`` marks a 10° tile); for merged
        extracts their ids joined with ``"+"``.
    url : str or None
        The extract's download URL; ``None`` for merged extracts (see ``sources``).
    bytes : int or None
        The extract's download size, if the provider reported it.
    download_seconds, crop_seconds : float
        Time spent downloading (near zero when the extract was already downloaded) and cropping.
    failed : list of (str, str)
        ``(url, error message)`` for smaller extracts whose download failed before this one.
    sources : list of ExtractSource
        The downloaded extracts, in merge order: one for a single extract, several for a merged
        one. For a merged file ``provider`` and ``extract`` join theirs with ``"+"``, ``url``
        is ``None`` and ``bytes`` is their total; ``crop_seconds`` then covers the merge.
    sha256 : str
        The SHA-256 hex digest of ``path``.
    snapshot : datetime or None
        The time the extract's data was taken, from its PBF header
        (``osmosis_replication_timestamp``, UTC); ``None`` when it has none. For merged
        extracts the oldest of the sources' times (each source's own is in ``sources``).
    """

    path: str
    provider: str
    extract: str
    url: str
    bytes: object
    download_seconds: float
    crop_seconds: float
    failed: list = field(default_factory=list)
    sources: list = field(default_factory=list)
    sha256: str = None
    snapshot: object = None

    def __fspath__(self):
        return self.path


def _must_cover_parts(must_cover):
    """``must_cover`` as ``(polygons, points_and_lines)`` in lon/lat, either part ``None``.

    Accepts a Shapely geometry of any type or a GeoDataFrame/GeoSeries (reprojected to
    EPSG:4326 when it has another CRS). The two kinds are united separately, so a point inside
    a polygon keeps its own, exact coverage requirement. Raises ``ValueError`` when it is empty.
    """
    if isinstance(must_cover, (gpd.GeoDataFrame, gpd.GeoSeries)):
        if must_cover.crs is not None:
            must_cover = must_cover.to_crs("EPSG:4326")
        geoms = list(must_cover.geometry.values)
    else:
        geoms = [must_cover]
    parts = list(shapely.get_parts(geoms))
    # Collections can hold multi-part geometries and further collections.
    while any(
        shapely.get_num_geometries(g) > 1 or g.geom_type.startswith(("Multi", "Geo"))
        for g in parts
    ):
        parts = list(shapely.get_parts(parts))
    parts = [g for g in parts if g is not None and not g.is_empty]
    polygons = [g for g in parts if g.geom_type == "Polygon"]
    others = [g for g in parts if g.geom_type != "Polygon"]
    if not parts:
        raise ValueError("must_cover is empty.")
    return (
        shapely.union_all(polygons) if polygons else None,
        shapely.union_all(others) if others else None,
    )


def _area_geometry(area):
    """Return ``area`` as one Shapely geometry in lon/lat.

    Accepts a Shapely geometry, a GeoDataFrame/GeoSeries (its geometries are unioned, after
    reprojecting to EPSG:4326 when it has another CRS) or ``[minx, miny, maxx, maxy]``.
    """
    if isinstance(area, (gpd.GeoDataFrame, gpd.GeoSeries)):
        if area.crs is not None:
            area = area.to_crs("EPSG:4326")
        geom = shapely.union_all(area.geometry.values)
    elif isinstance(area, BaseGeometry):
        geom = area
    else:
        geom = _bbox_to_polygon(area)
    if geom.is_empty:
        raise ValueError("The area is empty.")
    check_bounds(geom.bounds, "The area (%s)" % geom.geom_type)
    return geom


def _write_area_file(
    area,
    sources,
    crop,
    output_path,
    directory,
    workers=1,
    progress=None,
    update=False,
    name=None,
):
    """The file for :class:`AreaExtract`: the one extract, cropped to the area's bounding box
    when ``crop`` (to the area itself when ``crop="polygon"``); several extracts merged (and
    cropped) with :func:`pyrosm.merge_pbf`. Without ``crop``, one extract is itself the file,
    or is copied to ``output_path`` when given. The crop or merge shows its progress as
    ``progress`` says. The file is named after the area, or ``name`` when given, unless
    ``output_path`` is; a file pyrosm names is used again, unless ``update``, while its record
    says it was cut to this region from these extracts as they are now and it is unchanged
    since.
    """
    from pyrosm.pbf_export import crop_pbf, merge_pbf

    paths = [s.path for s in sources]
    if not crop and len(paths) == 1:
        if output_path is None:
            return paths[0]
        copy_atomic(paths[0], output_path)
        return os.fspath(output_path)
    region = {}
    if crop == "polygon":
        region["polygon"] = area
        area_name = "area_%s.osm.pbf" % hashlib.sha1(area.wkb).hexdigest()[:12]
    elif crop:
        region["bounding_box"] = box(*area.bounds)
        area_name = _bbox_filename(area.bounds)
    else:
        urls = "\n".join(s.url for s in sources).encode()
        area_name = "merged_%s.osm.pbf" % hashlib.sha1(urls).hexdigest()[:12]
    target = output_path or str(_default_target_dir(directory) / (name or area_name))
    cut = {key: hashlib.sha1(geom.wkb).hexdigest() for key, geom in region.items()}
    if output_path is None and not update and _made_from(target, paths, cut):
        return target
    Path(target).resolve().parent.mkdir(parents=True, exist_ok=True)
    if len(paths) == 1:
        written = crop_pbf(
            paths[0], target, workers=workers, progress=progress, **region
        )
    else:
        written = merge_pbf(paths, target, workers=workers, progress=progress, **region)
    if output_path is None:
        _record_made_from(written, paths, cut)
    return written


def _identities(path, sources, cut):
    """The record of the file ``path`` cut to the region ``cut`` from the files
    ``sources``: the identities (see :func:`~pyrosm.utils._file_identity`) of the file and
    of the sources, and the region."""
    return {
        "file": list(_file_identity(path)),
        "sources": [[os.fspath(s), *_file_identity(s)] for s in sources],
        "cut": cut,
    }


def _record_made_from(path, sources, cut):
    """Record that the file ``path``, as it is now, was cut to ``cut`` (the hash of the
    crop region by its kind, empty without a crop) from ``sources``."""
    record = json.dumps(_identities(path, sources, cut)).encode()
    write_atomic(sources_record(path), lambda out_file: out_file.write(record))


def _made_from(path, sources, cut):
    """Whether the file ``path`` was cut to ``cut`` from the files ``sources`` as they are
    now, and is unchanged since (see :func:`_record_made_from`)."""
    try:
        record = json.loads(sources_record(path).read_text())
        return record == _identities(path, sources, cut)
    except (OSError, ValueError):
        return False


def _write_with_provenance(
    area,
    sources,
    crop,
    output_path,
    directory,
    workers=1,
    progress=None,
    update=False,
    name=None,
):
    """Write the area's file (:func:`_write_area_file`) and read the provenance of it and of
    its sources afterwards, so they describe the bytes that were used. When a source changed
    meanwhile, or the written file changed before its provenance was read, both are done
    again, up to three times, then ``OSError``. Fills in each source's
    ``sha256`` and ``snapshot``; returns the file's path and ``{path: (sha256, snapshot)}``.
    """
    for _ in range(3):
        before = [_file_identity(s.path) for s in sources]
        path = _write_area_file(
            area, sources, crop, output_path, directory, workers, progress, update, name
        )
        written = _file_identity(path)
        provenance = {p: _provenance(p) for p in {path, *(s.path for s in sources)}}
        unchanged = [_file_identity(s.path) for s in sources] == before
        if unchanged and _file_identity(path) == written:
            for s in sources:
                s.sha256, s.snapshot = provenance[s.path]
            return path, provenance
    raise OSError(
        "The downloaded extracts kept changing while the area's file was written."
    )


def get_data_by_area(
    area,
    crop=True,
    update=False,
    directory=None,
    output_path=None,
    headers=None,
    timeout=_TIMEOUT,
    opener=None,
    strategy="single",
    must_cover=None,
    workers=None,
    progress=None,
    tolerance=_TOLERANCE,
):
    """Download the OSM data for ``area``: the smallest single extract that contains it, or a
    smaller set of extracts merged into one file.

    Compares Geofabrik extracts, BBBike city extracts and Movisda administrative areas
    and 1°/10° grid tiles, keeps those that contain the whole area (or ``must_cover``
    when given), and downloads the one with the smallest file (the first row of
    ``find_extracts(area, contains_only=True, must_cover=must_cover,
    tolerance=tolerance)``, which shows the choice without downloading). An extract may
    leave less than ``tolerance`` (0.1 % by default) of the area outside it; when it
    leaves 1 m² or more, a warning says how much of the area the data leaves out, and
    where. Before a download of 1 GB or more, a warning names the smallest extract, of at
    most a tenth of that size, that leaves out less than 1 % of the area (or of the
    polygons in ``must_cover``), when there is one. With ``strategy="smallest_total"`` it
    may instead download several extracts that together cover the area and merge them
    into one file (see ``strategy``). A download that fails with a network error or HTTP
    status 408, 425, 429 or 5xx is tried up to three times, waiting 1 s, 2 s or the
    server's ``Retry-After`` in between; when it still fails, the choice is made again
    without it, and when its provider answered 429 or 503, its request to slow down,
    also without the provider's other extracts that are not downloaded yet. An extract
    already downloaded is not downloaded again in the same call. By default the file is
    then cropped to the area's bounding box, or with ``crop="polygon"`` to the area
    itself.

    See https://pyrosm.readthedocs.io/en/stable/download_responsibly.html
    for what the data providers ask and how pyrosm keeps to it.

    Movisda cuts its extracts exactly at their edges, so features crossing the edge of a Movisda
    extract are clipped or missing there: open ways such as streets are cut at the edge and
    kept. A grid tile can leave out a whole closed way that crosses its edge, such as a
    building or a land-use area, including its part inside the area. To keep a grid tile's
    edges at least N metres outside the area, pass the area buffered by N metres (in a local
    metric CRS) as ``must_cover``. In a merged set the Movisda extract goes last, so where
    another extract holds a complete copy of such a feature, that copy is kept.

    Parameters
    ----------
    area : shapely geometry | GeoDataFrame | GeoSeries | list | tuple | numpy.ndarray
        The area of interest in lon/lat: a (Multi)Polygon, a GeoDataFrame/GeoSeries (its
        geometries are combined) or ``[minx, miny, maxx, maxy]``.

    crop : bool or "polygon"
        When ``True`` (default), crop the extract to the area's bounding box and return the
        cropped file, named ``bbox_<minx>_<miny>_<maxx>_<maxy>.osm.pbf``. With ``"polygon"``,
        crop it to the area itself, which must be a (Multi)Polygon: a node is kept when it
        lies inside the area or on its boundary, and a way that has a kept node is kept
        whole. The file is named ``area_<hash of the area>.osm.pbf``. A cropped file of these
        names is used again instead of cropping anew while it and the extracts it was cropped
        from are unchanged. When ``False``, return the full extract.

    update : bool
        When ``True``, download the extract again unless the provider answers that it has
        not changed since the last download (see :func:`pyrosm.get_data`), refresh the
        provider indexes and sizes, and crop again.

    directory : str, optional
        Directory for the downloads, the provider indexes and the cropped file. ``None``
        (default) uses a pyrosm temp directory.

    output_path : str, optional
        Path for the file pyrosm writes (overrides the automatic name), cropped anew on
        every call: the cropped file, or with ``crop=False`` a copy of the extract (a hard
        link where the file system allows one) or the merged file of a
        ``"smallest_total"`` set.

    headers, timeout, opener
        Network options for the index, size and download requests, as for
        :func:`find_extracts`.

    strategy : str
        ``"single"`` (default): the smallest extract that contains the area.
        ``"smallest_total"``: when extracts that together cover the area are smaller in total
        than that extract (or its size is unknown), download those and merge them with
        :func:`pyrosm.merge_pbf`. The set is found greedily (lowest size per area newly
        covered), so it is small but not guaranteed to be the smallest possible. Geofabrik,
        BBBike and Movisda administrative extracts may be combined, at most one of them from
        Movisda, which goes last in the merge; Movisda grid tiles are never combined. With
        ``crop=False`` the merged file is named ``merged_<hash of the URLs>.osm.pbf``.

    must_cover : shapely geometry | GeoDataFrame | GeoSeries, optional
        What the download must cover, in place of the whole area, e.g. the transit stops that
        routing needs, so sea or unserved edges of the area do not force a larger extract.
        Points and lines are covered exactly, polygons but for less than 1 m² (``tolerance``
        does not apply). To also
        require the streets around each stop, pass the stops buffered in a local metric CRS,
        e.g. ``stops.to_crs(stops.estimate_utm_crs()).buffer(300)``, or a hull of them to
        require the streets between stops as well. A GeoDataFrame or GeoSeries in another CRS
        is reprojected to lon/lat. The crop still follows ``area``, so parts of
        ``must_cover`` outside it are cropped away.

    workers : int | str
        Number of threads that crop (and merge) the downloaded file. By default (``None``,
        as ``"auto"``) the count is chosen as an out-of-core read does for the file's size;
        ``1`` runs sequentially. More workers are used only for a file with at least
        ``2 * workers`` data blocks, and the written file is the same for every value. With
        ``crop=False`` and a single extract nothing is cropped, so it has no effect. With
        ``PYROSM_DECODE_BACKEND=processes`` they are worker processes, one by default; on
        macOS and Windows each starts by importing the script, so a script that passes
        ``workers="auto"`` or ``workers > 1`` then needs the
        ``if __name__ == "__main__":`` guard; without it, or for a script read from stdin,
        the work runs in one process with a warning.

    progress : bool | callable | None
        ``None`` (default) follows :func:`pyrosm.enable_logging`, which is ``True`` unless
        set. ``True`` shows the download as a bar on stderr, a widget in Jupyter when
        ipywidgets is installed (``pip install "pyrosm[notebook]"``); without a terminal,
        only a line naming the file is printed. ``False`` shows nothing. A callable is called
        as ``progress(written, total)`` after each chunk of each download, with the bytes
        written so far and the file size, ``None`` when the server does not give it.
        The search for the extracts and the crop or merge show their progress the same
        way; a callable is then called with the percentage of the search (see
        :func:`find_extracts`) or of the crop or merge done (see :func:`pyrosm.merge_pbf`).

    tolerance : float
        The share of the area (``0 <= tolerance < 1``) that may lie outside the extract or
        extracts that count as containing it, or 1 m² when that is more; 0.001 (0.1 %) by
        default, so that a strip of sea or a spot at a border that a place's outline adds
        does not rule out the extract of that place. With ``0``, only slivers smaller than
        1 m² may lie outside. Not used with ``must_cover``.

    Returns
    -------
    AreaExtract
        The file path and the extract it came from; usable as a path.

    Raises
    ------
    ValueError
        If the area is empty, or has no width or no height, or ``must_cover`` is empty, or
        ``crop`` is a string other than ``"polygon"``, or ``crop="polygon"`` and the area is
        not a (Multi)Polygon, or ``workers`` is neither an integer of at least 1 nor ``"auto"``,
        or ``tolerance`` is not a number with ``0 <= tolerance < 1``.
    pyrosm.exceptions.ExtractNotFoundError
        If no extract (or set of extracts) contains the whole area, or ``must_cover`` when
        given (a ``ValueError`` subclass). For an area, or polygons in ``must_cover``, the
        message names up to three extracts that overlap it and leave out the least of it,
        with how much, and for the area, when 1 % or less would do, a ``tolerance`` with
        which the first of them would contain it.
    pyrosm.exceptions.ExtractDownloadError
        If every extract that contains the area failed to download; its ``errors`` hold the
        :class:`~pyrosm.exceptions.DownloadError` of each extract tried.
    pyrosm.exceptions.RequestRefusedError
        If an extract chosen was downloaded in full 3 times in the last 24 hours (see
        :func:`pyrosm.utils.download.download`); no other extract is tried instead.
    """
    return _get_area(
        area,
        crop,
        update,
        directory,
        output_path,
        headers,
        timeout,
        opener,
        strategy,
        must_cover,
        workers,
        progress,
        tolerance=tolerance,
    )


# The HTTP statuses with which a host asks its clients to stop or slow down.
_REFUSING_STATUSES = (429, 503)


def _without_failed(candidates, extract, error, downloaded):
    """``candidates`` without ``extract``, whose download failed with ``error`` (a
    :class:`~pyrosm.exceptions.DownloadError`). When its provider, which serves its extracts
    from one host, refused with HTTP status 429 or 503, also without the provider's other
    extracts, except those whose URLs are in ``downloaded`` (already downloaded). Returns them
    and the provider left out, or None."""
    if error.status not in _REFUSING_STATUSES:
        return candidates[candidates["url"] != extract.url], None
    keep = (candidates["provider"] != extract.provider) | candidates["url"].isin(
        list(downloaded)
    )
    return candidates[keep & (candidates["url"] != extract.url)], extract.provider


def _extract_source(extract, path):
    """The :class:`ExtractSource` of the candidate row ``extract``, downloaded to ``path``."""
    bytes_ = None if pd.isna(extract.bytes) else int(extract.bytes)
    return ExtractSource(extract.provider, extract.id, extract.url, bytes_, path)


def _url_result(urls):
    """The URL of the one extract that ``urls`` lists, or all of them as a list."""
    return urls[0] if len(urls) == 1 else urls


def _get_area(
    area,
    crop,
    update,
    directory,
    output_path,
    headers,
    timeout,
    opener,
    strategy,
    must_cover,
    workers,
    progress,
    name=None,
    download=True,
    tolerance=_TOLERANCE,
):
    """:func:`get_data_by_area`, whose arguments these are, with the file pyrosm writes
    named ``name`` instead of after the area; without ``download`` it returns the URLs of
    the extracts it would download instead, as a list. ``area`` can also be a function
    that gives it, called once the other arguments are checked."""
    from pyrosm.utils.download import download as _download_file

    validate_progress(progress)
    if strategy not in _STRATEGIES:
        raise ValueError(
            "strategy must be one of %s; got %r." % (", ".join(_STRATEGIES), strategy)
        )
    if isinstance(crop, str) and crop != "polygon":
        raise ValueError('crop must be True, False or "polygon"; got %r.' % (crop,))
    workers = validate_workers(workers)
    tolerance = _validate_tolerance(tolerance)
    parts = None if must_cover is None else _must_cover_parts(must_cover)
    geom = _area_geometry(area() if callable(area) else area)
    if crop == "polygon" and geom.geom_type not in ("Polygon", "MultiPolygon"):
        raise ValueError(
            'crop="polygon" needs a Polygon or MultiPolygon area; got %s.'
            % geom.geom_type
        )
    target = (geom, None) if parts is None else parts
    net = dict(headers=headers, timeout=timeout, opener=opener)
    candidates = find_extracts(
        geom,
        contains_only=strategy == "single",
        update=update,
        directory=directory,
        must_cover=must_cover,
        progress=progress,
        tolerance=tolerance,
        **net,
    )
    # must_cover is covered without a tolerance.
    choice_tolerance = tolerance if parts is None else 0.0
    area_tolerance = tolerance if parts is None else None

    def overlapping():
        """The candidates that overlap the target, also those that do not contain it,
        without those left out after failed downloads."""
        if strategy != "single":
            return candidates
        found = find_extracts(
            geom,
            directory=directory,
            must_cover=must_cover,
            progress=progress,
            tolerance=tolerance,
            **net,
        )
        for extract, error in left_out:
            found, _ = _without_failed(found, extract, error, downloaded)
        return found

    # The paths of the extracts downloaded so far, by URL: a choice made again reuses them.
    failed, errors, downloaded = [], [], {}
    # The extracts whose download failed, with their errors.
    left_out = []
    download_seconds = 0.0
    while (
        chosen := _choose(target, candidates, strategy, choice_tolerance)
    ) is not None:
        if not download:
            _warn_uncovered(chosen, target)
            return list(chosen["url"])
        _warn_large_download(chosen, downloaded, overlapping, target[0], area_tolerance)
        sources = []
        for extract in chosen.itertuples():
            path = downloaded.get(extract.url)
            if path is not None:
                sources.append(_extract_source(extract, path))
                continue
            log_event(
                logger,
                logging.INFO,
                "choose_extract",
                provider=extract.provider,
                extract=extract.name,
                megabytes=(
                    extract.bytes / 1e6 if pd.notna(extract.bytes) else "unknown"
                ),
            )
            filename = "%s_%s" % (
                extract.provider.lower(),
                extract_file_name(extract.url),
            )
            began = time.perf_counter()
            try:
                path = _download_file(
                    extract.url, filename, update, directory, progress=progress, **net
                )
            except RequestRefusedError:
                raise
            except DownloadError as e:
                failed.append((extract.url, str(e)))
                errors.append(e)
                left_out.append((extract, e))
                candidates, provider = _without_failed(
                    candidates, extract, e, downloaded
                )
                others = (
                    "" if provider is None else " and the other %s extracts" % provider
                )
                warnings.warn(
                    "Could not download %s (%s); choosing again without it%s."
                    % (extract.url, e, others),
                    stacklevel=_stacklevel_outside_pyrosm(),
                )
                break
            finally:
                download_seconds += time.perf_counter() - began
            downloaded[extract.url] = path
            sources.append(_extract_source(extract, path))
        else:
            _warn_uncovered(chosen, target)
            start = time.perf_counter()
            path, provenance = _write_with_provenance(
                geom,
                sources,
                crop,
                output_path,
                directory,
                workers,
                progress,
                update,
                name,
            )
            merged = len(sources) > 1
            total = [s.bytes for s in sources]
            sha256 = provenance[path][0]
            snapshots = [s.snapshot for s in sources if s.snapshot is not None]
            return AreaExtract(
                path=path,
                provider="+".join(s.provider for s in sources),
                extract="+".join(s.extract for s in sources),
                url=None if merged else sources[0].url,
                bytes=sum(total) if None not in total else None,
                download_seconds=download_seconds,
                crop_seconds=time.perf_counter() - start,
                failed=failed,
                sources=sources,
                sha256=sha256,
                snapshot=min(snapshots) if snapshots else None,
            )
    if not failed:
        what = "the area" if must_cover is None else "must_cover"
        raise ExtractNotFoundError(
            _not_found_message(what, overlapping(), target[0], area_tolerance)
        )
    raise ExtractDownloadError(
        "Could not download the extracts for the area; %d downloads failed: %s"
        % (len(failed), "; ".join("%s (%s)" % f for f in failed)),
        failed,
        errors=errors,
    )
