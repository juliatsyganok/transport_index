from pyrosm.data_manager import get_osm_data
from pyrosm.frames import prepare_geodataframe
from pyrosm.utils import validate_custom_filter, warn_empty_result


def get_poi_data(
    nodes,
    node_coordinates,
    way_records,
    relations,
    tags_as_columns,
    custom_filter,
    bounding_box,
    keep_metadata=True,
    relation_member_ways=None,
    complete_relations=False,
    steps=None,
):
    """The points of interest that pass ``custom_filter`` as a GeoDataFrame, read from
    the in-memory reader's parsed arrays. Returns ``None`` when nothing matches; the
    selection and the geometries are steps of ``steps`` (a
    :class:`~pyrosm.utils.progress.Steps`, or None)."""
    # Validate filter
    custom_filter = validate_custom_filter(custom_filter)

    # Call signature for fetching POIs
    nodes, ways, relation_ways, relations = get_osm_data(
        node_arrays=nodes,
        way_records=way_records,
        relations=relations,
        tags_as_columns=tags_as_columns,
        data_filter=custom_filter,
        filter_type="keep",
        osm_keys=None,
        keep_metadata=keep_metadata,
        relation_member_ways=relation_member_ways,
        steps=steps,
    )

    # If there weren't any data, return empty GeoDataFrame
    if nodes is None and ways is None and relations is None:
        warn_empty_result("pois")
        return None

    # Prepare GeoDataFrame
    gdf = prepare_geodataframe(
        nodes,
        node_coordinates,
        ways,
        relations,
        relation_ways,
        tags_as_columns,
        bounding_box,
        keep_metadata=keep_metadata,
        complete_relations=complete_relations,
        steps=steps,
    )

    return gdf
