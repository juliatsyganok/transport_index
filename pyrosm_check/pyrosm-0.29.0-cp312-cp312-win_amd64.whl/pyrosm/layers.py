from pyrosm.data_manager import get_osm_data
from pyrosm.frames import prepare_geodataframe
from pyrosm.utils import validate_custom_filter, require_layer_key, warn_empty_result

# Values of ``building`` that mark a part of a building (an entrance, a window) or say
# that a feature is not a building.
NOT_BUILDINGS = frozenset({"entrance", "window", "no"})


def get_layer_data(
    layer,
    result_name,
    nodes,
    node_coordinates,
    way_records,
    relations,
    tags_as_columns,
    custom_filter,
    bounding_box,
    keep_metadata=True,
    relation_member_ways=None,
    complete_relations=False,
    steps=None,
):
    """The elements of the layer ``layer`` (an OSM key, such as ``"building"``) as a
    GeoDataFrame, read from the in-memory reader's parsed arrays (without nodes when
    ``nodes`` is None); ``custom_filter`` narrows them. Returns ``None`` when nothing
    matches, with a warning naming ``result_name``; the selection and the geometries
    are steps of ``steps`` (a :class:`~pyrosm.utils.progress.Steps`, or None)."""
    # If custom_filter has not been defined, initialize with default
    if custom_filter is None:
        custom_filter = {layer: [True]}
    else:
        # Check that the custom filter is in correct format, then narrow it to the
        # layer, so every element kept is one of the layer's elements.
        custom_filter = validate_custom_filter(custom_filter)
        custom_filter = require_layer_key(custom_filter, layer)

    nodes, ways, relation_ways, relations = get_osm_data(
        node_arrays=nodes,
        way_records=way_records,
        relations=relations,
        tags_as_columns=tags_as_columns,
        data_filter=custom_filter,
        filter_type="keep",
        osm_keys=None,
        keep_metadata=keep_metadata,
        relation_member_ways=relation_member_ways,
        steps=steps,
    )

    # If there weren't any data, return empty GeoDataFrame
    if nodes is None and ways is None and relations is None:
        warn_empty_result(result_name)
        return None

    # Prepare GeoDataFrame
    gdf = prepare_geodataframe(
        nodes,
        node_coordinates,
        ways,
        relations,
        relation_ways,
        tags_as_columns,
        bounding_box,
        keep_metadata=keep_metadata,
        complete_relations=complete_relations,
        steps=steps,
    )
    return gdf


def without_building_parts(gdf):
    """``gdf``, buildings read with their nodes, without the nodes whose ``building`` value
    is in :data:`NOT_BUILDINGS`; ``None``, with a warning, when nothing is left."""
    if gdf is None:
        return None
    parts = (gdf["osm_type"] == "node") & gdf["building"].isin(NOT_BUILDINGS)
    if not parts.any():
        return gdf
    gdf = gdf[~parts].reset_index(drop=True)
    if len(gdf) == 0:
        warn_empty_result("buildings")
        return None
    return gdf
