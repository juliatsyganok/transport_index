from pyrosm.data_filter cimport filter_osm_records, filter_node_indices, \
    filter_array_dict_by_indices_or_mask, filter_relation_indices
from pyrosm._arrays cimport convert_to_arrays_and_drop_empty, convert_way_records_to_lists, concatenate_dicts_of_arrays
from pyrosm.tagparser cimport explode_tag_array
from pyrosm.filter_compiler import compile_custom_filter, CompiledFilter, rename_filter_key
from pyrosm.way_store import NodeTags, WayStore
from pyrosm.geometry import AREA_BY_TAGS, tags_make_area
from pyrosm.utils.progress import COLLECTING, start_step
import numpy as np

cdef get_data_filter_and_osm_keys(custom_filter):
    # Advanced (opt-in) filters compile to a CompiledFilter predicate; its positive keys are
    # the candidate-key gate. compile_custom_filter leaves a plain dict (or an already-compiled
    # filter) as-is, so calling it here again is safe.
    custom_filter = compile_custom_filter(custom_filter)
    if isinstance(custom_filter, CompiledFilter):
        return custom_filter, list(custom_filter.positive_keys)

    osm_keys = []
    if isinstance(custom_filter, dict):
        data_filter = {}
        for key, tags in custom_filter.items():
            if not isinstance(key, str):
                raise ValueError(f"OSM key of the 'custom_filter' "
                                 f"should be text. "
                                 f"Got: {key} with type {type(key)}.")
            osm_keys.append(key)

            # # If osm-key has been defined as True,
            # # all tags should be kept, hence, no further filtering
            # # should be done.
            # if tags == True:
            #     continue

            if isinstance(tags, list):
                # Check that all values used for filtering are text (except None/True).
                # Even numeric data should be passed as string.
                for tag in tags:
                    if tag is None:
                        continue
                    if tag is True:
                        continue
                    elif not isinstance(tag, str):
                        raise ValueError(f"OSM tag of the 'custom_filter' "
                                         f"should be text. "
                                         f"Got: {tag} with type {type(tag)}.")
            elif isinstance(tags, str):
                tags = [tags]

            data_filter[key] = tags
        return data_filter, osm_keys
    else:
        raise ValueError(f"'custom_filter' should be a Python dictionary. "
                         f"Got {custom_filter} with type {type(custom_filter)}.")


cpdef parse_custom_filter(custom_filter):
    """Python entry point: normalise a ``custom_filter`` dict into ``(data_filter,
    osm_keys)`` exactly as the in-memory reader does, so an alternative reader filters with
    identical semantics."""
    return get_data_filter_and_osm_keys(custom_filter)


cdef get_relation_arrays(relations, osm_keys, data_filter, filter_type, bint keep_all=False):
    # Get indices for MultiPolygons that also passes data_filter
    indices = filter_relation_indices(relations, osm_keys, data_filter, filter_type, keep_all)
    # If no building relations were found, return None
    if len(indices) == 0:
        return None
    # Otherwise, filter the data accordingly
    return filter_array_dict_by_indices_or_mask(relations, indices)

cdef separate_relation_ways(way_records, relation_way_ids):
    cdef int i, n = len(way_records)
    # Create lookup dict
    relation_ids = dict.fromkeys(relation_way_ids, None)
    normal_ways = []
    relation_ways = []
    for i in range(0, n):
        way = way_records[i]
        try:
            # Check if way is part of relation
            relation_ids[way["id"]]
            relation_ways.append(way)
        except Exception as e:
            normal_ways.append(way)
    return normal_ways, relation_ways

cdef get_way_arrays(way_records, relation_way_ids, osm_keys, tags_as_columns, data_filter, filter_type, relation_member_ways=None, bint keep_all=False):
    """The way arrays of the kept standalone ways and of the relations' member ways:
    ``(way_arrays, relation_arrays)``, each ``None`` when empty. The standalone ways also
    carry, under ``AREA_BY_TAGS``, whether their tags make them areas when closed. From a
    WayStore, only the ways the key check of filter_osm_records can keep are built."""
    # A way record holds its tag keyed "id" as "id_tag", and "id" is the way's id.
    data_filter, osm_keys = rename_filter_key(data_filter, osm_keys, "id", "id_tag")
    if isinstance(way_records, WayStore):
        way_records = way_records.records(
            way_records.candidate_rows(osm_keys, relation_way_ids, keep_all)
        )

    # Get all ways including the ones associated with relations
    ways = filter_osm_records(way_records,
                      data_filter,
                      osm_keys,
                      relation_way_ids,
                      filter_type,
                      keep_all)

    # Completed member ways fetched outside the bounding box (complete_relations).
    # They are kept out of way_records so they never leak into normal way features;
    # route only those belonging to THIS layer's relations into relation assembly.
    extra_relation_ways = []
    if relation_member_ways and relation_way_ids is not None:
        _, extra_relation_ways = separate_relation_ways(relation_member_ways, relation_way_ids)

    # If there is not data in the area, do not continue
    # (return None for ways and relations)
    if len(ways) == 0 and len(extra_relation_ways) == 0:
        return None, None

    relation_arrays = None
    if relation_way_ids is not None:
        # Separate ways that are part of a relation
        ways, relation_ways = separate_relation_ways(ways, relation_way_ids)
        relation_ways = relation_ways + extra_relation_ways
        if len(relation_ways) > 0:
            relation_ways = convert_way_records_to_lists(relation_ways, tags_as_columns)
            relation_arrays = convert_to_arrays_and_drop_empty(relation_ways)

    # Process separated ways; the area rule of closed ways reads all of a way's tags, also
    # those that are not columns.
    if len(ways) > 0:
        area_by_tags = tags_make_area(ways)
        ways = convert_way_records_to_lists(ways, tags_as_columns)
        way_arrays = convert_to_arrays_and_drop_empty(ways)
        way_arrays[AREA_BY_TAGS] = area_by_tags
    else:
        way_arrays = None

    return way_arrays, relation_arrays

cpdef _get_osm_ways_and_relations(way_records, relations, osm_keys, tags_as_columns, data_filter, filter_type, bint keep_metadata=True, relation_member_ways=None, bint keep_all=False):
    return get_osm_ways_and_relations(way_records, relations, osm_keys, tags_as_columns, data_filter, filter_type, keep_metadata, relation_member_ways, keep_all)

cdef get_osm_ways_and_relations(way_records, relations, osm_keys, tags_as_columns, data_filter, filter_type, bint keep_metadata=True, relation_member_ways=None, bint keep_all=False):

    # Structural columns that must always be kept; element metadata (timestamp,
    # version) is materialized only when keep_metadata is True. Build a new list
    # instead of mutating the caller's tags_as_columns in place (callers may pass
    # a shared list such as Conf.tags.<feature>).
    tags_as_columns = tags_as_columns + ["id", "nodes"]
    if keep_metadata:
        tags_as_columns = tags_as_columns + ["timestamp", "version"]

    # If any way records weren't passed in, cannot parse anything
    if way_records is None:
        return None, None, None

    # Get relations for specified OSM keys (one or multiple)
    if relations is not None:
        filtered_relations = get_relation_arrays(relations, osm_keys, data_filter, filter_type, keep_all)

        # Get all way-ids that are associated with relations
        relation_way_ids = None
        if filtered_relations is not None:
            members = concatenate_dicts_of_arrays(filtered_relations['members'])
            relation_way_ids = members["member_id"]

            if type(relation_way_ids) not in [list, np.ndarray]:
                raise ValueError("'relation_way_ids' should be a list or an array.")
    else:
        relation_way_ids = None
        filtered_relations = None

    # Get ways (separately as "normal" ways and relation_ways)
    ways, relation_ways = get_way_arrays(way_records,
                                         relation_way_ids,
                                         osm_keys,
                                         tags_as_columns,
                                         data_filter,
                                         filter_type,
                                         relation_member_ways,
                                         keep_all)

    # If relation ways could not be parsed, also relations should be returned as None
    if relation_ways is None:
        filtered_relations = None

    # If there weren't any ways or relations return None
    if ways is None and relation_ways is None:
        return None, None, None

    return ways, relation_ways, filtered_relations

cdef get_osm_nodes(node_arrays, osm_keys, tags_as_columns, data_filter, filter_type, bint keep_all=False):
    """The nodes of ``node_arrays`` that ``data_filter`` keeps or excludes by
    ``filter_type`` (on the keys ``osm_keys``; every tagged node with ``keep_all``), with
    their tags as the ``tags_as_columns`` columns and a JSON ``tags`` column of the others,
    or None when no node passes."""
    tags = node_arrays["tags"]
    if isinstance(tags, NodeTags):
        # Check only the tagged nodes that carry one of the keys
        rows = tags.candidate_rows(osm_keys, keep_all)
        kept = filter_node_indices({"tags": tags[rows]}, osm_keys, data_filter, filter_type, keep_all)
        indices = rows[np.asarray(kept, dtype=np.int64)]
    else:
        # Get indices for Nodes that passes data_filter
        indices = filter_node_indices(node_arrays, osm_keys, data_filter, filter_type, keep_all)
    # If no nodes were found, return None
    if len(indices) == 0:
        return None
    # Otherwise, filter the data accordingly
    filtered_nodes = filter_array_dict_by_indices_or_mask(node_arrays, indices)
    # explode_tag_array returns the non-empty tag columns and the JSON 'tags' column of
    # the leftover tags, which replaces the nodes' tag dicts.
    tags = explode_tag_array(filtered_nodes["tags"], tags_as_columns)
    filtered_nodes["tags"] = tags.pop("tags")
    filtered_nodes.update(tags)
    return filtered_nodes

cdef _get_osm_data(node_arrays, way_records, relations, tags_as_columns, data_filter, filter_type, osm_keys, bint keep_metadata=True, relation_member_ways=None, bint keep_all=False):
    """The nodes, ways, relation member ways and relations that pass the filter
    ``data_filter`` (its keys ``osm_keys`` parsed from it when None), as arrays."""
    if osm_keys is None:
        # Convert filter to appropriate form and parse keys
        data_filter, osm_keys = get_data_filter_and_osm_keys(data_filter)
    # The tag pyrosm returns as "id_tag" is keyed "id" in the elements' tags.
    data_filter, osm_keys = rename_filter_key(data_filter, osm_keys, "id_tag", "id")

    # A truthy node_arrays is a non-empty dict of node columns. An empty dict (e.g. when a
    # bounding box selected no nodes) or None means there are no nodes to filter.
    if node_arrays:
        # Get nodes
        node_arrays = get_osm_nodes(node_arrays, osm_keys, tags_as_columns, data_filter, filter_type, keep_all)
    else:
        node_arrays = None

    # Parse ways and relations
    ways, relation_ways, filtered_relations = get_osm_ways_and_relations(way_records, relations, osm_keys, tags_as_columns, data_filter, filter_type, keep_metadata, relation_member_ways, keep_all)
    return node_arrays, ways, relation_ways, filtered_relations

cpdef get_osm_data(node_arrays, way_records, relations, tags_as_columns, data_filter, filter_type, osm_keys=None, bint keep_metadata=True, relation_member_ways=None, bint keep_all=False, steps=None):
    """The elements that pass the filter (see :func:`_get_osm_data`), selected as the step
    :data:`~pyrosm.utils.progress.COLLECTING` of ``steps`` (or None)."""
    start_step(steps, COLLECTING)
    return _get_osm_data(node_arrays, way_records, relations, tags_as_columns, data_filter, filter_type, osm_keys, keep_metadata, relation_member_ways, keep_all)
